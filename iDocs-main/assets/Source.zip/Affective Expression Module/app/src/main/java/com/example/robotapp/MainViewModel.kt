package com.example.robotapp

import android.content.Context
import android.widget.Toast
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.squareup.moshi.Moshi
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class MainViewModel @Inject constructor(private val api:Api): ViewModel() {

    val info=MutableLiveData<Resource<InfoModel>>()

    fun getInfo(){

        MainScope().launch(Dispatchers.IO){

            info.postValue(Resource.loading())
            try{
                val res=api.getInfo()
                info.postValue(Resource.success(data = res))
            }catch (ex:Exception){
                info.postValue(Resource.error(data = null))
                ex.printStackTrace()
            }
        }
    }



}
