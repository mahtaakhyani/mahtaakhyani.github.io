package com.example.robotapp

import com.squareup.moshi.Json

data class InfoModel(
    @Json(name = "face") val face: String?,
    @Json(name = "sound") val sound: String?,
    @Json(name = "status") val status: Int?,
    @Json(name = "message") val message: String?,
)