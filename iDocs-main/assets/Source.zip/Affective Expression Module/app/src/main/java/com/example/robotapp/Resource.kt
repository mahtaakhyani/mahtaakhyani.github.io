package com.example.robotapp

enum class ResourceStatus {
    SUCCESS,
    ERROR,
    LOADING
}

data class Resource<out T>(val status: ResourceStatus, val data: T?) {
    companion object {
        fun <T> success(data: T): Resource<T> = Resource(status = ResourceStatus.SUCCESS, data = data)

        fun <T> error(data: T?): Resource<T> = Resource(status = ResourceStatus.ERROR, data = data)

        fun <T> loading(): Resource<T> = Resource(status = ResourceStatus.LOADING, data = null)
    }
}