package com.example.robotapp

import com.squareup.moshi.Json

data class Status(
    @Json(name = "status") val status: String,
)