package com.example.robotapp

import okhttp3.RequestBody
import retrofit2.http.*

interface Api {

    @GET
    suspend fun getInfo(@Url url:String=Utils.SERVER_BASE_URL+"reqcli" ): InfoModel

    @POST
    @Headers("Content-Type: application/json")
    suspend fun reportStatus(@Url url:String=Utils.SERVER_BASE_URL+"reqcli" ,@Body status: Status)

}