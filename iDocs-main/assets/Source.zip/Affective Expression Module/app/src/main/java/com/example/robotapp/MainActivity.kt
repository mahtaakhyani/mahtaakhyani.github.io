package com.example.robotapp

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doOnTextChanged
import androidx.lifecycle.ViewModelProvider
import com.example.robotapp.ResourceStatus.*
import com.example.robotapp.databinding.ActivityMainBinding
import dagger.hilt.android.AndroidEntryPoint


@AndroidEntryPoint
class MainActivity : AppCompatActivity() {

    lateinit var viewModel: MainViewModel
    private lateinit var binding: ActivityMainBinding


    @SuppressLint("SourceLockedOrientationActivity")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)
        viewModel =  ViewModelProvider(this).get(MainViewModel::class.java)

        setupUi()
        setupListeners()
    }


    private fun setupUi()
    {

        binding.editTextServerBaseUrl.setText(Utils.SERVER_BASE_URL)
        binding.buttonConnect.setOnClickListener { viewModel.getInfo() }
        binding.editTextServerBaseUrl.doOnTextChanged { text, _, _, _ ->
            val url=text.toString()
            if (url.isNotEmpty())
                Utils.SERVER_BASE_URL=if (url.endsWith("/")) url else "$url/"
        }

        binding.buttonStart.setOnClickListener {

            val i = Intent(this@MainActivity, PlayerActivity::class.java)

            val videoUrl=viewModel.info.value?.data?.face
            if (videoUrl != null && videoUrl.isNotEmpty())
            {
                i.putExtra("video_url", videoUrl)
            }

            val audioUrl=viewModel.info.value?.data?.sound
            if (audioUrl != null && audioUrl.isNotEmpty())
            {
                i.putExtra("audio_url", audioUrl)
            }

            startActivity(i)

        }



    }

    private fun setupListeners()
    {
        viewModel.info.observe(this) {
            when(it.status){
                LOADING ->{
                    binding.progressBar.visibility= View.VISIBLE
                    binding.buttonConnect.visibility= View.INVISIBLE
                }
                SUCCESS -> {
                    binding.progressBar.visibility= View.GONE
                    binding.buttonConnect.visibility= View.VISIBLE
                    Toast.makeText(applicationContext,"OK !", Toast.LENGTH_LONG).show()
                    binding.textViewFaceUrl.text=it.data!!.face ?: "null"
                    binding.textViewSoundUrl.text=it.data.sound ?: "null"
                    binding.textViewStatus.text=it.data.status.toString()
                    binding.textViewMessage.text=it.data.message ?: "null"


                }
                ERROR->{
                    binding.progressBar.visibility= View.GONE
                    binding.buttonConnect.visibility= View.VISIBLE
                    Toast.makeText(applicationContext,"Error !", Toast.LENGTH_LONG).show()
                    binding.textViewFaceUrl.text= "-"
                    binding.textViewSoundUrl.text= "-"
                    binding.textViewStatus.text= "-"
                    binding.textViewMessage.text= "-"
                }
            }

        }
    }

}