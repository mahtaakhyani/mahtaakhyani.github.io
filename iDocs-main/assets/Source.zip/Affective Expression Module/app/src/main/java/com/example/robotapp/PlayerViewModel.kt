package com.example.robotapp

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class PlayerViewModel @Inject constructor(private val api:Api): ViewModel() {

    val videoUrl= MutableLiveData<String>()
    val audioUrl= MutableLiveData<String>()

    fun checkForNewStreamUrls(){

        MainScope().launch(Dispatchers.IO){
            while (true){

                delay(2500L)
                try{
                    val info=api.getInfo()

                    if (info.face!=videoUrl.value){
                        videoUrl.postValue(info.face)
                    }

                    if (info.sound!=audioUrl.value){
                        audioUrl.postValue(info.sound)
                    }


                }catch (ex:Exception){
                    ex.printStackTrace()
                }
            }

        }
    }

    fun reportStatus(message:String)
    {
        MainScope().launch(Dispatchers.IO){
            try {
                api.reportStatus(status = Status(message))
            }catch (ex:Exception){
                ex.printStackTrace()
            }

        }


    }



}
