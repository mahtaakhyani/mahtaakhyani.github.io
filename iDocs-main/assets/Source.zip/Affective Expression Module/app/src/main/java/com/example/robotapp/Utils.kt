package com.example.robotapp

object Utils {
    public var SERVER_BASE_URL:String="http://10.0.2.2/"
}