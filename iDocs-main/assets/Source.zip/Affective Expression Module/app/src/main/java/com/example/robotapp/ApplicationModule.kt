package com.example.robotapp

import android.content.Context
import com.google.android.exoplayer2.database.DatabaseProvider
import com.google.android.exoplayer2.database.StandaloneDatabaseProvider
import com.google.android.exoplayer2.upstream.DefaultDataSource
import com.google.android.exoplayer2.upstream.DefaultHttpDataSource
import com.google.android.exoplayer2.upstream.FileDataSource
import com.google.android.exoplayer2.upstream.cache.CacheDataSink
import com.google.android.exoplayer2.upstream.cache.CacheDataSource
import com.google.android.exoplayer2.upstream.cache.LeastRecentlyUsedCacheEvictor
import com.google.android.exoplayer2.upstream.cache.SimpleCache
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.io.File
import javax.inject.Singleton


@Module
@InstallIn(SingletonComponent::class)
class ApplicationModule {

    /*
        Retrofit-related dependencies
    */

    /*@Provides
    @Singleton
    fun provideOkHttpClient(): OkHttpClient {

        var tlsSpecs: List<ConnectionSpec> = listOf(ConnectionSpec.MODERN_TLS)
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
            tlsSpecs = listOf(ConnectionSpec.COMPATIBLE_TLS)
        }

        return OkHttpClient.Builder()
            .connectionSpecs(tlsSpecs)
            .build()
    }*/

    @Provides
    @Singleton
    fun provideMoshi(): Moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()

    @Provides
    @Singleton
    fun provideRetrofit(/*okHttpClient: OkHttpClient, */moshi: Moshi): Retrofit {
        return Retrofit.Builder()
            //.client(okHttpClient)
            .baseUrl(Utils.SERVER_BASE_URL)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
    }

    @Provides
    @Singleton
    fun provideApi(retrofit: Retrofit): Api = retrofit.create(Api::class.java)

    @Provides
    @Singleton
    fun provideExoCache(@ApplicationContext context: Context): CacheDataSource.Factory {

        val evictor = LeastRecentlyUsedCacheEvictor((500 * 1024 * 1024).toLong())
        val databaseProvider: DatabaseProvider = StandaloneDatabaseProvider(context)
        val simpleCache = SimpleCache(File(context.cacheDir, "media"), evictor, databaseProvider)

        val cacheSink = CacheDataSink.Factory().setCache(simpleCache)
        val upstreamFactory = DefaultDataSource.Factory(context, DefaultHttpDataSource.Factory())
        val downStreamFactory = FileDataSource.Factory()

        return CacheDataSource.Factory()
            .setCache(simpleCache)
            .setCacheWriteDataSinkFactory(cacheSink)
            .setCacheReadDataSourceFactory(downStreamFactory)
            .setUpstreamDataSourceFactory(upstreamFactory)
            .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)

    }


}