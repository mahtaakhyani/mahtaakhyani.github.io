package com.example.robotapp

import android.annotation.SuppressLint
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import com.example.robotapp.databinding.ActivityPlayerBinding
import com.google.android.exoplayer2.*
import com.google.android.exoplayer2.source.DefaultMediaSourceFactory
import com.google.android.exoplayer2.source.TrackGroupArray
import com.google.android.exoplayer2.trackselection.TrackSelectionArray
import com.google.android.exoplayer2.upstream.cache.CacheDataSource
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.PrintWriter
import java.io.StringWriter
import java.io.Writer
import javax.inject.Inject


@AndroidEntryPoint
class PlayerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPlayerBinding
    lateinit var viewModel: PlayerViewModel

    lateinit var videoPlayer : ExoPlayer
    lateinit var audioPlayer : ExoPlayer

    private lateinit var imageViewFullScreen: ImageView
    private lateinit var imageViewLock: ImageView
    private lateinit var linearLayoutControlUp: LinearLayout
    private lateinit var linearLayoutControlBottom: LinearLayout

    @Inject
    lateinit var exoCache:CacheDataSource.Factory


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPlayerBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)
        viewModel =  ViewModelProvider(this).get(PlayerViewModel::class.java)

        videoPlayer= ExoPlayer.Builder(applicationContext).build()
        binding.exoPlayerView.player = videoPlayer

        audioPlayer=ExoPlayer.Builder(applicationContext).build()

        videoPlayer.repeatMode= Player.REPEAT_MODE_ONE
        audioPlayer.repeatMode= Player.REPEAT_MODE_ONE

        videoPlayer.playWhenReady=true
        audioPlayer.playWhenReady=true

        setupUi()
        setupListeners()


        val extras = intent.extras
        if (extras != null) {
            extras.getString("video_url")?.let{
                viewModel.videoUrl.postValue(it)
            }
            extras.getString("audio_url")?.let{
                viewModel.audioUrl.postValue(it)
            }
        }

        viewModel.checkForNewStreamUrls()

    }

    private fun setupUi(){
        imageViewFullScreen = findViewById(R.id.imageViewFullScreen)
        imageViewLock = findViewById(R.id.imageViewLock)
        linearLayoutControlUp = findViewById(R.id.linearLayoutControlUp)
        linearLayoutControlBottom = findViewById(R.id.linearLayoutControlBottom)

    }

    private fun setupListeners()
    {
        setLockScreen()
        setFullScreen()

        viewModel.videoUrl.observe(this){
            playVideoStream(it)
        }

        viewModel.audioUrl.observe(this){
            playAudioStream(it)
        }

        videoPlayer.addListener(object : Player.Listener
        {
            override fun onPlayerError(error: PlaybackException) {
                viewModel.reportStatus("VideoPlayer Exception: " + error.stackTraceToString())
            }

        })

        audioPlayer.addListener(object : Player.Listener
        {
            override fun onPlayerError(error: PlaybackException) {
                viewModel.reportStatus("AudioPlayer Exception: " + error.stackTraceToString())
            }

        })


    }


    private fun playVideoStream(videoUrl:String?){

        try {
            videoUrl?.let {
                val mediaItem: MediaItem = MediaItem.fromUri(it)

                val mediaSource = DefaultMediaSourceFactory(exoCache).createMediaSource(mediaItem)
                videoPlayer.setMediaSource(mediaSource)

                videoPlayer.prepare()
                videoPlayer.play()

                MainScope().launch {
                    delay(3000L)
                    if (videoPlayer.isPlaying){
                        viewModel.reportStatus("Video connected successfully: $videoUrl")
                        Log.i("Status","Video connected successfully!")
                    }else{
                        viewModel.reportStatus("Failed to connect to video: $videoUrl")
                        Log.i("Status","Failed to connect to video!")
                    }
                }
            }


        } catch (e: Exception) {
            e.printStackTrace()
        }

    }


    private fun playAudioStream(audioUrl:String?){

        try {
            audioUrl?.let {
                val mediaItem: MediaItem = MediaItem.fromUri(it)

                val mediaSource = DefaultMediaSourceFactory(exoCache).createMediaSource(mediaItem)
                audioPlayer.setMediaSource(mediaSource)

                audioPlayer.prepare()
                audioPlayer.play()

                MainScope().launch {
                    delay(3000L)
                    if (audioPlayer.isPlaying) {
                        viewModel.reportStatus("Audio connected successfully: $audioUrl")
                        Log.i("Status","Audio connected successfully!")
                    } else {
                        viewModel.reportStatus("Failed to connect to audio: $audioUrl")
                        Log.i("Status","Failed to connect to audio!")
                    }
                }
            }


        } catch (e: Exception) {
            e.printStackTrace()
        }
    }


    private fun lockScreen(lock: Boolean) {
        if (lock) {
            linearLayoutControlUp.visibility = View.INVISIBLE
            linearLayoutControlBottom.visibility = View.INVISIBLE
        } else {
            linearLayoutControlUp.visibility = View.VISIBLE
            linearLayoutControlBottom.visibility = View.VISIBLE
        }
    }


    private fun setLockScreen() {
        imageViewLock.setOnClickListener {
            if (!isLock) {
                imageViewLock.setImageDrawable(
                    ContextCompat.getDrawable(
                        applicationContext,
                        R.drawable.ic_baseline_lock
                    )
                )
            } else {
                imageViewLock.setImageDrawable(
                    ContextCompat.getDrawable(
                        applicationContext,
                        R.drawable.ic_baseline_lock_open
                    )
                )
            }
            isLock = !isLock
            lockScreen(isLock)
        }
    }


    @SuppressLint("SourceLockedOrientationActivity")
    private fun setFullScreen() {
        imageViewFullScreen.setOnClickListener {

            if (!isFullScreen) {
                imageViewFullScreen.setImageDrawable(
                    ContextCompat.getDrawable(
                        applicationContext,
                        R.drawable.ic_baseline_fullscreen_exit
                    )
                )
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            } else {
                imageViewFullScreen.setImageDrawable(
                    ContextCompat.getDrawable(
                        applicationContext,
                        R.drawable.ic_baseline_fullscreen
                    )
                )
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            }
            isFullScreen = !isFullScreen
        }
    }


    override fun onBackPressed() {
        if (isLock) return
        if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            imageViewFullScreen.performClick()
        } else super.onBackPressed()
    }


    override fun onStop() {
        super.onStop()
        videoPlayer.stop()
        audioPlayer.stop()
    }

    override fun onDestroy() {
        super.onDestroy()
        videoPlayer.release()
        audioPlayer.release()
    }

    override fun onPause() {
        super.onPause()
        videoPlayer.pause()
        audioPlayer.pause()
    }

    companion object {
        var isFullScreen = false
        var isLock = false
    }

}